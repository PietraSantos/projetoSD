const users = [
    { id: 1, username: 'atendente-email', password: 'password', department: 'email' },
    { id: 2, username: 'atendente-hardware', password: '123456', department: 'hardware' },
    { id: 3, username: 'atendente-software', password: 'abcdef', department: 'software' }
  ];
  
  module.exports = users;
  